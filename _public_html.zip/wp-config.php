<?php
/** Enable W3 Total Cache */
define('WP_CACHE', true); // Added by W3 Total Cache



/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'u545182578_p4DWc' );

/** Database username */
define( 'DB_USER', 'u545182578_dfjpo' );

/** Database password */
define( 'DB_PASSWORD', 'CLXepiSa7v' );

/** Database hostname */
define( 'DB_HOST', '127.0.0.1' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          ')7TNuO5jUwUr5VwehM(a?p16~`W0r8LE.vI$DD6=,<L>33aLgl>#,g)L7xMar=>Q' );
define( 'SECURE_AUTH_KEY',   'xT[10HltO#Y|4/Mxe1eL5K;yrTjNBM>Q}6qm[|xX?`E(sKJaboyLa.,<-w[`Hy9x' );
define( 'LOGGED_IN_KEY',     '&`s:; Sh~u<_Zp6$K..z1^<$dJy`~l(B<MUnwA~{S&MMX*N,6hw3IYoE5P`FI_Y}' );
define( 'NONCE_KEY',         '!@[7F>S*vSR^=9/n0?1!4R|.)!PT1IBHbf)l 94dt?-#{T!b;@Hp(/q(=X,]T#Py' );
define( 'AUTH_SALT',         '2>gaQGErCQnE?Pm3)Udp?,s*Nc2r_T[T57Q3^l-H!A^&:(cO71l :p0l4lqd3L+B' );
define( 'SECURE_AUTH_SALT',  'r;_F`3@4fqk^4#7!Vc<x2!HCQB}E 0$R-b1SQh[Nzg;nXHqy}Ym&@6L.A&!; =*k' );
define( 'LOGGED_IN_SALT',    ']@QNoNk2TJ~,F+aq+mnJ7zA+;rvoI^ha>[]]30Ab.Cg]!<yl$40erVNfKZrLahBd' );
define( 'NONCE_SALT',        'a I@oYpT=B1Z^*VH_~#Zb2xtg5=$mC|C)HL]mf6r;mg Y$FyF>SQ-~8,*2X5#)<&' );
define( 'WP_CACHE_KEY_SALT', '3m|(086#Wn8Q#;{#E46EC?SBwTiLE43Ddy{dVssHwc[hX6,^3P^*~P~Fn&6jTSn(' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'FS_METHOD', 'direct' );
define( 'COOKIEHASH', 'a1c083d7ef5eb173f18e7febb035cca1' );
define( 'WP_AUTO_UPDATE_CORE', 'minor' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
