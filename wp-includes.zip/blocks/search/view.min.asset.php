<?php return array('dependencies' => array(), 'version' => '765a40956d200c79d99e');
